//
//  ZGCLine.m
//  ZGCTouchTracker
//
//  Created by EviLKerneL on 5/31/15.
//  Copyright (c) 2015 EviLKerneL. All rights reserved.
//

#import "ZGCLine.h"

@implementation ZGCLine

@end
